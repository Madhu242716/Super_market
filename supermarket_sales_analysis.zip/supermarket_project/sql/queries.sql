-- ============================================================
-- SUPERMARKET SALES ANALYSIS - SQL QUERIES
-- Database: SQLite / MySQL
-- ============================================================

-- ============================================================
-- TABLE CREATE
-- ============================================================

CREATE TABLE IF NOT EXISTS supermarket_sales (
    invoice_id    VARCHAR(20),
    branch        CHAR(1),
    city          VARCHAR(50),
    customer_type VARCHAR(20),
    gender        VARCHAR(10),
    product_line  VARCHAR(50),
    unit_price    DECIMAL(10,2),
    quantity      INT,
    tax           DECIMAL(10,4),
    total         DECIMAL(10,4),
    date          DATE,
    time          TIME,
    payment       VARCHAR(20),
    cogs          DECIMAL(10,4),
    gross_margin  DECIMAL(10,4),
    gross_income  DECIMAL(10,4),
    rating        DECIMAL(3,1)
);

-- ============================================================
-- QUERY 1: Branch-wise Total Revenue
-- ============================================================

SELECT
    branch,
    COUNT(*)              AS total_transactions,
    SUM(total)            AS total_revenue,
    ROUND(AVG(total), 2)  AS avg_per_sale,
    ROUND(AVG(rating), 2) AS avg_rating
FROM supermarket_sales
GROUP BY branch
ORDER BY total_revenue DESC;

-- ============================================================
-- QUERY 2: Top Product Lines by Revenue
-- ============================================================

SELECT
    product_line,
    SUM(total)            AS revenue,
    SUM(quantity)         AS units_sold,
    ROUND(AVG(rating), 2) AS avg_rating
FROM supermarket_sales
GROUP BY product_line
ORDER BY revenue DESC;

-- ============================================================
-- QUERY 3: Monthly Sales Trend
-- ============================================================

-- SQLite version
SELECT
    strftime('%m', date)   AS month_num,
    strftime('%Y-%m', date) AS month,
    COUNT(*)               AS transactions,
    ROUND(SUM(total), 2)   AS monthly_revenue
FROM supermarket_sales
GROUP BY strftime('%Y-%m', date)
ORDER BY month_num;

-- MySQL version
-- SELECT
--     MONTH(date)     AS month_num,
--     MONTHNAME(date) AS month_name,
--     COUNT(*)        AS transactions,
--     SUM(total)      AS monthly_revenue
-- FROM supermarket_sales
-- GROUP BY MONTH(date), MONTHNAME(date)
-- ORDER BY month_num;

-- ============================================================
-- QUERY 4: Payment Method Analysis
-- ============================================================

SELECT
    payment,
    COUNT(*)                                                   AS transaction_count,
    ROUND(SUM(total), 2)                                       AS total_revenue,
    ROUND(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM supermarket_sales), 2) AS percentage
FROM supermarket_sales
GROUP BY payment
ORDER BY transaction_count DESC;

-- ============================================================
-- QUERY 5: Gender-wise Purchase Behaviour
-- ============================================================

SELECT
    gender,
    product_line,
    COUNT(*)             AS purchases,
    ROUND(SUM(total), 2) AS total_spent
FROM supermarket_sales
GROUP BY gender, product_line
ORDER BY gender, total_spent DESC;

-- ============================================================
-- QUERY 6: Customer Type Analysis
-- ============================================================

SELECT
    customer_type,
    COUNT(*)              AS visit_count,
    ROUND(SUM(total), 2)  AS total_revenue,
    ROUND(AVG(total), 2)  AS avg_purchase,
    ROUND(AVG(rating), 2) AS avg_rating
FROM supermarket_sales
GROUP BY customer_type
ORDER BY total_revenue DESC;

-- ============================================================
-- QUERY 7: Peak Hours Analysis
-- ============================================================

-- SQLite version
SELECT
    strftime('%H', time)  AS hour,
    COUNT(*)              AS transactions,
    ROUND(SUM(total), 2)  AS revenue
FROM supermarket_sales
GROUP BY strftime('%H', time)
ORDER BY transactions DESC
LIMIT 5;

-- ============================================================
-- QUERY 8: High Value Transactions (Top 10)
-- ============================================================

SELECT
    invoice_id,
    branch,
    product_line,
    total,
    rating,
    date
FROM supermarket_sales
ORDER BY total DESC
LIMIT 10;

-- ============================================================
-- QUERY 9: City-wise Performance
-- ============================================================

SELECT
    city,
    branch,
    COUNT(*)              AS transactions,
    ROUND(SUM(total), 2)  AS revenue,
    ROUND(AVG(rating), 2) AS avg_rating
FROM supermarket_sales
GROUP BY city, branch
ORDER BY revenue DESC;

-- ============================================================
-- QUERY 10: Low Rating Transactions (for improvement)
-- ============================================================

SELECT
    branch,
    product_line,
    COUNT(*) AS low_rating_count
FROM supermarket_sales
WHERE rating < 5
GROUP BY branch, product_line
ORDER BY low_rating_count DESC;

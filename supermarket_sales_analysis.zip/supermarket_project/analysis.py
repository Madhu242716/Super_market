# ============================================================
# SUPERMARKET SALES ANALYSIS
# Tools: Python, Pandas, Matplotlib, Seaborn
# Dataset: Kaggle - Supermarket Sales
# ============================================================

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import os

# Output folder create pannum
os.makedirs('output', exist_ok=True)

# ============================================================
# STEP 1 - LOAD DATA
# ============================================================
print("=" * 50)
print("STEP 1: Loading Data...")
print("=" * 50)

df = pd.read_csv('data/supermarket_sales.csv')

print(f"Shape        : {df.shape}")
print(f"Columns      : {list(df.columns)}")
print("\nFirst 5 rows:")
print(df.head())

# ============================================================
# STEP 2 - DATA CLEANING
# ============================================================
print("\n" + "=" * 50)
print("STEP 2: Cleaning Data...")
print("=" * 50)

# Null values check
print("Null Values:\n", df.isnull().sum())

# Duplicate check
print(f"\nDuplicates: {df.duplicated().sum()}")

# Date column - datetime format convert
df['Date'] = pd.to_datetime(df['Date'])

# New columns extract
df['Month']      = df['Date'].dt.month
df['Month_Name'] = df['Date'].dt.strftime('%B')
df['Day']        = df['Date'].dt.day_name()
df['Hour']       = pd.to_datetime(df['Time'], format='%H:%M').dt.hour

# Drop nulls if any
df.dropna(inplace=True)

print(f"\nCleaned Shape: {df.shape}")
print("Data cleaning done! ✅")

# ============================================================
# STEP 3 - ANALYSIS
# ============================================================
print("\n" + "=" * 50)
print("STEP 3: Analysis...")
print("=" * 50)

# 1. Branch-wise Revenue
branch_sales = df.groupby('Branch')['Total'].sum().reset_index()
branch_sales.columns = ['Branch', 'Total_Revenue']
print("\nBranch Revenue:\n", branch_sales)

# 2. Top Product Lines
product_sales = df.groupby('Product line')['Total'].sum().sort_values(ascending=False).reset_index()
product_sales.columns = ['Product_Line', 'Revenue']
print("\nTop Products:\n", product_sales)

# 3. Monthly Sales
monthly_sales = df.groupby(['Month', 'Month_Name'])['Total'].sum().reset_index()
monthly_sales = monthly_sales.sort_values('Month')
print("\nMonthly Sales:\n", monthly_sales)

# 4. Payment Method
payment = df['Payment'].value_counts().reset_index()
payment.columns = ['Payment_Method', 'Count']
print("\nPayment Methods:\n", payment)

# 5. Average Rating by Branch
avg_rating = df.groupby('Branch')['Rating'].mean().round(2).reset_index()
print("\nAvg Rating:\n", avg_rating)

# 6. Gender-wise Sales
gender_sales = df.groupby('Gender')['Total'].sum().reset_index()
print("\nGender Sales:\n", gender_sales)

# 7. Customer Type Analysis
customer = df.groupby('Customer type').agg(
    Total_Revenue=('Total', 'sum'),
    Avg_Purchase=('Total', 'mean'),
    Visit_Count=('Invoice ID', 'count')
).round(2).reset_index()
print("\nCustomer Type:\n", customer)

# ============================================================
# STEP 4 - VISUALIZATIONS
# ============================================================
print("\n" + "=" * 50)
print("STEP 4: Creating Charts...")
print("=" * 50)

sns.set_theme(style="whitegrid")
colors = ['#2E75B6', '#70AD47', '#ED7D31', '#FFC000', '#FF0000', '#7030A0']

# Chart 1 - Branch Sales
plt.figure(figsize=(8, 5))
bars = plt.bar(branch_sales['Branch'], branch_sales['Total_Revenue'],
               color=colors[:3], edgecolor='white', linewidth=1.5)
plt.title('Total Revenue by Branch', fontsize=16, fontweight='bold', pad=15)
plt.xlabel('Branch', fontsize=12)
plt.ylabel('Total Revenue ($)', fontsize=12)
for bar in bars:
    plt.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 500,
             f"${bar.get_height():,.0f}", ha='center', fontsize=11, fontweight='bold')
plt.tight_layout()
plt.savefig('output/1_branch_sales.png', dpi=150, bbox_inches='tight')
plt.close()
print("Chart 1 saved ✅")

# Chart 2 - Monthly Sales Line
plt.figure(figsize=(10, 5))
plt.plot(monthly_sales['Month_Name'], monthly_sales['Total'],
         marker='o', color='#2E75B6', linewidth=2.5, markersize=8,
         markerfacecolor='white', markeredgewidth=2)
plt.fill_between(range(len(monthly_sales)), monthly_sales['Total'], alpha=0.1, color='#2E75B6')
plt.title('Monthly Sales Trend', fontsize=16, fontweight='bold', pad=15)
plt.xlabel('Month', fontsize=12)
plt.ylabel('Total Sales ($)', fontsize=12)
plt.xticks(range(len(monthly_sales)), monthly_sales['Month_Name'], rotation=15)
plt.tight_layout()
plt.savefig('output/2_monthly_trend.png', dpi=150, bbox_inches='tight')
plt.close()
print("Chart 2 saved ✅")

# Chart 3 - Product Pie
plt.figure(figsize=(9, 9))
wedges, texts, autotexts = plt.pie(
    product_sales['Revenue'],
    labels=product_sales['Product_Line'],
    autopct='%1.1f%%',
    colors=colors,
    startangle=140,
    pctdistance=0.8
)
for text in autotexts:
    text.set_fontsize(10)
    text.set_fontweight('bold')
plt.title('Sales by Product Line', fontsize=16, fontweight='bold', pad=20)
plt.tight_layout()
plt.savefig('output/3_product_pie.png', dpi=150, bbox_inches='tight')
plt.close()
print("Chart 3 saved ✅")

# Chart 4 - Payment Method
plt.figure(figsize=(8, 5))
bars = plt.bar(payment['Payment_Method'], payment['Count'],
               color=colors[:3], edgecolor='white', linewidth=1.5)
plt.title('Payment Method Distribution', fontsize=16, fontweight='bold', pad=15)
plt.xlabel('Payment Method', fontsize=12)
plt.ylabel('Number of Transactions', fontsize=12)
for bar in bars:
    plt.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 2,
             str(int(bar.get_height())), ha='center', fontsize=12, fontweight='bold')
plt.tight_layout()
plt.savefig('output/4_payment_method.png', dpi=150, bbox_inches='tight')
plt.close()
print("Chart 4 saved ✅")

# Chart 5 - Gender Sales
plt.figure(figsize=(7, 5))
bars = plt.bar(gender_sales['Gender'], gender_sales['Total'],
               color=['#2E75B6', '#ED7D31'], edgecolor='white', linewidth=1.5)
plt.title('Sales by Gender', fontsize=16, fontweight='bold', pad=15)
plt.xlabel('Gender', fontsize=12)
plt.ylabel('Total Sales ($)', fontsize=12)
for bar in bars:
    plt.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 300,
             f"${bar.get_height():,.0f}", ha='center', fontsize=12, fontweight='bold')
plt.tight_layout()
plt.savefig('output/5_gender_sales.png', dpi=150, bbox_inches='tight')
plt.close()
print("Chart 5 saved ✅")

# Chart 6 - Rating Distribution
plt.figure(figsize=(9, 5))
sns.histplot(df['Rating'], bins=20, color='#2E75B6', edgecolor='white', linewidth=0.5)
plt.axvline(df['Rating'].mean(), color='red', linestyle='--', linewidth=2,
            label=f"Mean: {df['Rating'].mean():.2f}")
plt.title('Customer Rating Distribution', fontsize=16, fontweight='bold', pad=15)
plt.xlabel('Rating', fontsize=12)
plt.ylabel('Count', fontsize=12)
plt.legend(fontsize=11)
plt.tight_layout()
plt.savefig('output/6_rating_distribution.png', dpi=150, bbox_inches='tight')
plt.close()
print("Chart 6 saved ✅")

# ============================================================
# STEP 5 - SAVE CLEANED DATA
# ============================================================
print("\n" + "=" * 50)
print("STEP 5: Saving Cleaned Data...")
print("=" * 50)

df.to_csv('data/supermarket_cleaned.csv', index=False)
print("Cleaned CSV saved ✅")

# ============================================================
# SUMMARY
# ============================================================
print("\n" + "=" * 50)
print("ANALYSIS SUMMARY")
print("=" * 50)
print(f"Total Transactions : {len(df)}")
print(f"Total Revenue      : ${df['Total'].sum():,.2f}")
print(f"Average Sale       : ${df['Total'].mean():,.2f}")
print(f"Best Branch        : {branch_sales.loc[branch_sales['Total_Revenue'].idxmax(), 'Branch']}")
print(f"Top Product        : {product_sales.iloc[0]['Product_Line']}")
print(f"Avg Rating         : {df['Rating'].mean():.2f}")
print("=" * 50)
print("\nAll done! Check output/ folder for charts. ✅")

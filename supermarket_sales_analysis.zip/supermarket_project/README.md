# 🛒 Supermarket Sales Analysis

> Data Analysis project using Python, SQL, and Power BI

---

## 📌 Project Overview

Analyzed **1,000+ supermarket transactions** to uncover sales trends, top-performing products, and customer behaviour across 3 branches.

---

## 🛠️ Tools Used

| Tool | Purpose |
|------|---------|
| Python (Pandas) | Data cleaning & analysis |
| Matplotlib / Seaborn | Data visualization |
| SQL | Data querying |
| Power BI | Interactive dashboard |
| Excel | Initial data exploration |

---

## 📁 Project Structure

```
supermarket-sales-analysis/
│
├── data/
│   ├── supermarket_sales.csv     ← Raw dataset (Kaggle)
│   └── supermarket_cleaned.csv   ← Cleaned dataset
│
├── sql/
│   └── queries.sql               ← 10 SQL queries
│
├── output/
│   ├── 1_branch_sales.png
│   ├── 2_monthly_trend.png
│   ├── 3_product_pie.png
│   ├── 4_payment_method.png
│   ├── 5_gender_sales.png
│   └── 6_rating_distribution.png
│
├── analysis.py                   ← Main Python script
└── README.md
```

---

## 📊 Key Findings

- **Branch C** had the highest total revenue
- **Food & Beverages** was the top-selling product line
- **January** recorded the highest monthly sales
- **Ewallet** was the most preferred payment method
- Average customer rating: **6.97 / 10**

---

## 🚀 How to Run

```bash
# 1. Install libraries
pip install pandas numpy matplotlib seaborn

# 2. Add dataset
# Download from Kaggle and place in data/ folder
# https://www.kaggle.com/datasets/aungpyaeap/supermarket-sales

# 3. Run analysis
python analysis.py

# 4. Charts will be saved in output/ folder
```

---

## 📈 Dataset

- **Source:** [Kaggle - Supermarket Sales](https://www.kaggle.com/datasets/aungpyaeap/supermarket-sales)
- **Rows:** 1,000 transactions
- **Columns:** 17 features

---

*Project by Madhu Priya K | Data Analyst Portfolio*
